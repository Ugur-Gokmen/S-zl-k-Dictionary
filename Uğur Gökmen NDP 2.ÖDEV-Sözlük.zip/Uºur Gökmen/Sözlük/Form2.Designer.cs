﻿namespace Yeni_Deneme
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.lblKelimeSayaci = new System.Windows.Forms.Label();
            this.lblPuan = new System.Windows.Forms.Label();
            this.lblSoru = new System.Windows.Forms.Label();
            this.bttnSecenek1 = new System.Windows.Forms.Button();
            this.bttnSecenek2 = new System.Windows.Forms.Button();
            this.bttnSecenek3 = new System.Windows.Forms.Button();
            this.bttnSecenek4 = new System.Windows.Forms.Button();
            this.lblSure = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblKalan = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblKelimeSayaci
            // 
            this.lblKelimeSayaci.AutoSize = true;
            this.lblKelimeSayaci.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKelimeSayaci.Location = new System.Drawing.Point(113, 65);
            this.lblKelimeSayaci.Name = "lblKelimeSayaci";
            this.lblKelimeSayaci.Size = new System.Drawing.Size(109, 39);
            this.lblKelimeSayaci.TabIndex = 0;
            this.lblKelimeSayaci.Text = "label1";
            // 
            // lblPuan
            // 
            this.lblPuan.AutoSize = true;
            this.lblPuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPuan.Location = new System.Drawing.Point(587, 41);
            this.lblPuan.Name = "lblPuan";
            this.lblPuan.Size = new System.Drawing.Size(109, 39);
            this.lblPuan.TabIndex = 1;
            this.lblPuan.Text = "label2";
            // 
            // lblSoru
            // 
            this.lblSoru.AutoSize = true;
            this.lblSoru.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSoru.Location = new System.Drawing.Point(350, 179);
            this.lblSoru.Name = "lblSoru";
            this.lblSoru.Size = new System.Drawing.Size(109, 39);
            this.lblSoru.TabIndex = 2;
            this.lblSoru.Text = "label3";
            // 
            // bttnSecenek1
            // 
            this.bttnSecenek1.Location = new System.Drawing.Point(120, 321);
            this.bttnSecenek1.Name = "bttnSecenek1";
            this.bttnSecenek1.Size = new System.Drawing.Size(195, 55);
            this.bttnSecenek1.TabIndex = 3;
            this.bttnSecenek1.Text = "button1";
            this.bttnSecenek1.UseVisualStyleBackColor = true;
            // 
            // bttnSecenek2
            // 
            this.bttnSecenek2.Location = new System.Drawing.Point(511, 321);
            this.bttnSecenek2.Name = "bttnSecenek2";
            this.bttnSecenek2.Size = new System.Drawing.Size(185, 55);
            this.bttnSecenek2.TabIndex = 4;
            this.bttnSecenek2.Text = "button2";
            this.bttnSecenek2.UseVisualStyleBackColor = true;
            // 
            // bttnSecenek3
            // 
            this.bttnSecenek3.Location = new System.Drawing.Point(120, 411);
            this.bttnSecenek3.Name = "bttnSecenek3";
            this.bttnSecenek3.Size = new System.Drawing.Size(195, 52);
            this.bttnSecenek3.TabIndex = 5;
            this.bttnSecenek3.Text = "button3";
            this.bttnSecenek3.UseVisualStyleBackColor = true;
            // 
            // bttnSecenek4
            // 
            this.bttnSecenek4.Location = new System.Drawing.Point(511, 411);
            this.bttnSecenek4.Name = "bttnSecenek4";
            this.bttnSecenek4.Size = new System.Drawing.Size(185, 52);
            this.bttnSecenek4.TabIndex = 6;
            this.bttnSecenek4.Text = "button4";
            this.bttnSecenek4.UseVisualStyleBackColor = true;
            // 
            // lblSure
            // 
            this.lblSure.AutoSize = true;
            this.lblSure.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSure.Location = new System.Drawing.Point(357, 83);
            this.lblSure.Name = "lblSure";
            this.lblSure.Size = new System.Drawing.Size(109, 39);
            this.lblSure.TabIndex = 8;
            this.lblSure.Text = "label4";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(357, 221);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 109);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(357, -3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(109, 83);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // lblKalan
            // 
            this.lblKalan.AutoSize = true;
            this.lblKalan.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKalan.Location = new System.Drawing.Point(12, 25);
            this.lblKalan.Name = "lblKalan";
            this.lblKalan.Size = new System.Drawing.Size(303, 29);
            this.lblKalan.TabIndex = 11;
            this.lblKalan.Text = "Geriye Kalan Kelime Sayısı";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 475);
            this.Controls.Add(this.lblKalan);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblSure);
            this.Controls.Add(this.bttnSecenek4);
            this.Controls.Add(this.bttnSecenek3);
            this.Controls.Add(this.bttnSecenek2);
            this.Controls.Add(this.bttnSecenek1);
            this.Controls.Add(this.lblSoru);
            this.Controls.Add(this.lblPuan);
            this.Controls.Add(this.lblKelimeSayaci);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblKelimeSayaci;
        private System.Windows.Forms.Label lblPuan;
        private System.Windows.Forms.Label lblSoru;
        private System.Windows.Forms.Button bttnSecenek1;
        private System.Windows.Forms.Button bttnSecenek2;
        private System.Windows.Forms.Button bttnSecenek3;
        private System.Windows.Forms.Button bttnSecenek4;
        private System.Windows.Forms.Label lblSure;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblKalan;
    }
}